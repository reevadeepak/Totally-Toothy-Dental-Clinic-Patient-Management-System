<?php
session_start();
include("db.php");

if(!isset($_SESSION['reset_email']) || !isset($_SESSION['reset_verified'])){
    header("Location: forgot_password.php");
    exit();
}

$msg = "";
$email = $_SESSION['reset_email'];

if(isset($_POST['txtsubmit'])){
    $txtpassword  = $_POST['txtpassword'];
    $txtpassword2 = $_POST['txtpassword2'];

    if(empty($txtpassword) || empty($txtpassword2)){
        $msg = "<div class='message error'>All fields are required.</div>";
    } elseif(strlen($txtpassword) < 8){
        $msg = "<div class='message error'>Password must be at least 8 characters.</div>";
    } elseif(!preg_match('/[A-Z]/', $txtpassword)){
        $msg = "<div class='message error'>Password must contain at least one uppercase letter.</div>";
    } elseif(!preg_match('/[0-9]/', $txtpassword)){
        $msg = "<div class='message error'>Password must contain at least one number.</div>";
    } elseif(!preg_match('/[!@#$%^&*]/', $txtpassword)){
        $msg = "<div class='message error'>Password must contain at least one special character (!@#$%^&*).</div>";
    } elseif($txtpassword !== $txtpassword2){
        $msg = "<div class='message error'>Passwords do not match.</div>";
    } else {
        $hashedPassword = password_hash($txtpassword, PASSWORD_DEFAULT);

        // Get PatientID from email
        $stmt = $conn->prepare("SELECT PatientID FROM Patient WHERE Email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->bind_result($patientID);
        $stmt->fetch();
        $stmt->close();

        // Update password
        $stmt2 = $conn->prepare("UPDATE PatientUser SET PasswordHash = ? WHERE PatientID = ?");
        $stmt2->bind_param("si", $hashedPassword, $patientID);
        $stmt2->execute();
        $stmt2->close();

        // Delete the reset code
        $del = $conn->prepare("DELETE FROM PasswordReset WHERE Email = ?");
        $del->bind_param("s", $email);
        $del->execute();
        $del->close();

        // Clear session
        unset($_SESSION['reset_email']);
        unset($_SESSION['reset_verified']);

        $conn->close();
        $msg = "<div class='message success'>Password updated successfully! <a href='login.php'>Click here to login.</a></div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Totally Toothy – Reset Password</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include("header.php"); ?>
<div class="container">
    <div class="form-box">
        <h2>Reset Password</h2>
        <?php echo $msg; ?>
        <form method="post" action="reset_password.php">
            <div class="form-group">
                <label>New Password:</label>
                <input type="password" name="txtpassword" required>
                <small style="color:#666;">Min 8 characters, must include uppercase, number and special character (!@#$%^&*)</small>
            </div>
            <div class="form-group">
                <label>Confirm New Password:</label>
                <input type="password" name="txtpassword2" required>
            </div>
            <input type="submit" name="txtsubmit" value="Update Password" class="btn" style="width:100%;">
        </form>
    </div>
</div>
<?php include("footer.php"); ?>
</body>
</html>