<?php
?>

<footer>
    <div class="footer-container">
        <div class="footer-section">
            <div class="footer-logo-section">
                <div class="footer-logo">
                    <img src="images/logosss.jpg" alt="Totally Toothy Dental Clinic" class="logo-img">
                </div>
                <div class="footer-info">
                    <div class="logo-and-title">
                        <h3>Totally Toothy Dental Clinic</h3>
                    </div>
                    <p>Dubai Healthcare City, Dubai, UAE</p>
                    <p>Phone: +971 50467 0790</p>
                    <p>Email: totallytoothyclinic@gmail.com</p>
                    <p>Open Monday to Saturday | 9:00 AM - 5:00 PM</p>
                </div>
            </div>
        </div>

        <div class="footer-section">
            <h3>Quick Links</h3>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="treatments.php">Treatments</a></li>
                <li><a href="contactus.php">Contact</a></li>
                <li><a href="terms.php">Terms & Conditions</a></li>
                <li><a href="privacy.php">Privacy Policy</a></li>
            </ul>
        </div>

        <div class="footer-section">
            <h3>Patient Portal</h3>
            <ul>
                <?php if (isset($_SESSION['patient_id'])): ?>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="book_appointment.php">Book Appointment</a></li>
                    <li><a href="my_appointments.php">My Appointments</a></li>
                    <li><a href="update.php">Update Profile</a></li>
                    <li><a href="search_slots.php">Find Available Slots</a></li>
                    <li><a href="logout.php">Logout</a></li>
                <?php else: ?>
                    <li><a href="register.php">Register</a></li>
                    <li><a href="login.php">Login</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>

    <div class="footer-bottom">
        <div class="footer-social">
            <a href="https://www.instagram.com/totallytoothydentist" target="_blank">Instagram</a>
        </div>
        <p>© Copyright 2025 by Totally Toothy Dental Clinic. All Rights Reserved.</p>
    </div>
</footer>