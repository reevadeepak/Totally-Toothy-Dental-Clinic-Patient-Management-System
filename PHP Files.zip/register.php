<?php
session_start();

if(isset($_SESSION['patient_id'])){
    header("Location: dashboard.php");
    exit();
}

include("db.php");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

$msg = "";

if(isset($_POST['txtsubmit'])){

    $txtfullname   = $_POST['txtfullname'];
    $txtcontact    = $_POST['txtcontact'];
    $txtemail      = $_POST['txtemail'];
    $txtaddress    = $_POST['txtaddress'];
    $txtusername   = $_POST['txtusername'];
    $txtpassword   = $_POST['txtpassword'];
    $txtpassword2  = $_POST['txtpassword2'];
    $chkterms      = isset($_POST['chkterms']) ? 1 : 0;

    if(empty($txtfullname) || empty($txtcontact) || empty($txtemail) ||
       empty($txtaddress)  || empty($txtusername) || empty($txtpassword)){
        $msg = "<div class='message error'>All fields are required.</div>";
    } elseif(strlen($txtpassword) < 8){
        $msg = "<div class='message error'>Password must be at least 8 characters.</div>";
    } elseif(!preg_match('/[A-Z]/', $txtpassword)){
        $msg = "<div class='message error'>Password must contain at least one uppercase letter.</div>";
    } elseif(!preg_match('/[0-9]/', $txtpassword)){
        $msg = "<div class='message error'>Password must contain at least one number.</div>";
    } elseif(!preg_match('/[!@#$%^&*]/', $txtpassword)){
        $msg = "<div class='message error'>Password must contain at least one special character (!@#$%^&*).</div>";
    } elseif($txtpassword !== $txtpassword2){
        $msg = "<div class='message error'>Passwords do not match.</div>";
    } elseif($chkterms == 0){
        $msg = "<div class='message error'>You must accept the Terms and Conditions.</div>";
    } else {
        // Check if email already exists
        $stmt = $conn->prepare("SELECT PatientID FROM Patient WHERE Email = ?");
        $stmt->bind_param("s", $txtemail);
        $stmt->execute();
        $stmt->store_result();

        if($stmt->num_rows > 0){
            $msg = "<div class='message error'>Email already exists. <a href='login.php'>Click here to login.</a></div>";
            $stmt->close();
        } else {
            $stmt->close();

            // Check if username already exists
            $stmt2 = $conn->prepare("SELECT PatientID FROM PatientUser WHERE Username = ?");
            $stmt2->bind_param("s", $txtusername);
            $stmt2->execute();
            $stmt2->store_result();

            if($stmt2->num_rows > 0){
                $msg = "<div class='message error'>Username already taken. Please choose another.</div>";
                $stmt2->close();
            } else {
                $stmt2->close();

                // Insert into Patient
                $stmt3 = $conn->prepare("INSERT INTO Patient (FullName, ContactNumber, Email, HomeAddress) VALUES (?, ?, ?, ?)");
                $stmt3->bind_param("ssss", $txtfullname, $txtcontact, $txtemail, $txtaddress);

                if($stmt3->execute()){
                    $newPatientID = $conn->insert_id;
                    $stmt3->close();

                    // Hash password
                    $hashedPassword = password_hash($txtpassword, PASSWORD_DEFAULT);

                    // Insert into PatientUser
                    $stmt4 = $conn->prepare("INSERT INTO PatientUser (PatientID, Username, PasswordHash) VALUES (?, ?, ?)");
                    $stmt4->bind_param("iss", $newPatientID, $txtusername, $hashedPassword);

                    if($stmt4->execute()){
                        $stmt4->close();

                        // Send confirmation email
                        $mail = new PHPMailer(true);
                        try {
                            $mail->isSMTP();
                            $mail->Host       = 'smtp.gmail.com';
                            $mail->SMTPAuth   = true;
                            $mail->Username   = 'totallytoothyclinic@gmail.com';
                            $mail->Password   = 'uras fmiw nrne ikph';
                            $mail->SMTPSecure = 'tls';
                            $mail->Port       = 587;
                            $mail->CharSet    = 'UTF-8';

                            $mail->setFrom('totallytoothyclinic@gmail.com', 'Totally Toothy Clinic');
                            $mail->addAddress($txtemail, $txtfullname);

                            $mail->Subject = 'Welcome to Totally Toothy Clinic!';
                            $mail->Body    = "Dear $txtfullname,\n\nThank you for registering with Totally Toothy Clinic!\n\nYour account has been successfully created.\nYou can now log in using your username: $txtusername\n\nWe look forward to seeing you smile!\n\nRegards,\nTotally Toothy Clinic";

                            $mail->send();
                        } catch (Exception $e) {
                            // Email failed but account still created
                        }

                        $msg = "<div class='message success'>Account created successfully! <a href='login.php'>Click here to login.</a></div>";
                    } else {
                        $msg = "<div class='message error'>Could not create login account.</div>";
                    }
                } else {
                    $msg = "<div class='message error'>Registration failed. Please try again.</div>";
                }
                $conn->close();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Totally Toothy – Register</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include("header.php"); ?>

<div class="container">
    <div class="form-box">
        <h2>Patient Registration</h2>

        <?php echo $msg; ?>

        <form method="post" action="register.php">
            <div class="form-group">
                <label>Full Name:</label>
                <input type="text" name="txtfullname" required>
            </div>
            <div class="form-group">
                <label>Contact Number:</label>
                <input type="text" name="txtcontact" required>
            </div>
            <div class="form-group">
                <label>Email Address:</label>
                <input type="email" name="txtemail" required>
            </div>
            <div class="form-group">
                <label>Home Address:</label>
                <input type="text" name="txtaddress" required>
            </div>
            <div class="form-group">
                <label>Username:</label>
                <input type="text" name="txtusername" required>
            </div>
            <div class="form-group">
                <label>Password:</label>
                <input type="password" name="txtpassword" required>
                <small style="color:#666;">Min 8 characters, must include uppercase, number and special character (!@#$%^&*)</small>
            </div>
            <div class="form-group">
                <label>Re-type Password:</label>
                <input type="password" name="txtpassword2" required>
            </div>
            <div class="form-group checkbox-group">
                <input type="checkbox" name="chkterms" required>
                <label>I have read and agree to the <a href="terms.php" target="_blank" style="color: #0b6e8a; text-decoration: underline;">Terms & Conditions</a> and <a href="privacy.php" target="_blank" style="color: #0b6e8a; text-decoration: underline;">Privacy Policy</a></label>
            </div>
            <div class="form-group">
                <input type="submit" name="txtsubmit" value="Register" class="btn" style="width:100%;">
                <input type="reset" value="Clear" class="btn" style="width:100%; margin-top:10px; background-color:#ccc;">
            </div>
        </form>

        <p class="small-text">Already have an account? <a href="login.php">Login here</a></p>
    </div>
</div>

<?php include("footer.php"); ?>
</body>
</html>