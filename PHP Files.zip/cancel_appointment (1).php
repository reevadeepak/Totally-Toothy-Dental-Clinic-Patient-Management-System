<?php
session_start();
if(!isset($_SESSION['patient_id'])){
    header("Location: login.php");
    exit();
}
include("db.php");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

$patientID = $_SESSION['patient_id'];
$patientName = $_SESSION['patient_name'];
$appointmentID = isset($_GET['id']) ? $_GET['id'] : 0;

// Check the appointment date and get details before cancelling
$check = $conn->query("SELECT a.ApptDate, a.ApptTime, t.TreatmentName, d.FullName AS DoctorName, p.Email
                        FROM Appointment a
                        JOIN Treatment t ON a.TreatmentID = t.TreatmentID
                        JOIN Doctor d ON a.DoctorID = d.DoctorID
                        JOIN Patient p ON a.PatientID = p.PatientID
                        WHERE a.AppointmentID = $appointmentID AND a.PatientID = $patientID");
$appt = $check->fetch_assoc();

if(!$appt || $appt['ApptDate'] < date('Y-m-d')){
    header("Location: my_appointments.php");
    exit();
}

// First delete the invoice (foreign key constraint)
$conn->query("DELETE FROM Invoice WHERE AppointmentID = $appointmentID");
// Then delete the appointment
$conn->query("DELETE FROM Appointment WHERE AppointmentID = $appointmentID AND PatientID = $patientID");
$conn->close();

// Send cancellation email
$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'totallytoothyclinic@gmail.com';
    $mail->Password   = 'uras fmiw nrne ikph';
    $mail->SMTPSecure = 'tls';
    $mail->Port       = 587;
    $mail->CharSet = 'UTF-8';
    $mail->setFrom('totallytoothyclinic@gmail.com', 'Totally Toothy Clinic');
    $mail->addAddress($appt['Email'], $patientName);

    $mail->Subject = 'Appointment Cancellation – Totally Toothy Clinic';
    $mail->Body    = "Dear $patientName,\n\nYour appointment has been successfully cancelled.\n\nCancelled Appointment Details:\nDate: {$appt['ApptDate']}\nTime: {$appt['ApptTime']}\nDoctor: {$appt['DoctorName']}\nTreatment: {$appt['TreatmentName']}\n\nIf you would like to rebook, please visit our website.\n\nRegards,\nTotally Toothy Clinic";

    $mail->send();
} catch (Exception $e) {
    // Email failed but cancellation still went through
}

header("Location: my_appointments.php");
exit();
?>