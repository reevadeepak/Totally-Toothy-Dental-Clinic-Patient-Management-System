

<?php
session_start();
include("db.php");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

$msg = "";

if(isset($_POST['txtsubmit'])){
    $txtemail = $_POST['txtemail'];

    if(empty($txtemail)){
        $msg = "<div class='message error'>Please enter your email.</div>";
    } else {
        // Check if email exists
        $stmt = $conn->prepare("SELECT PatientID FROM Patient WHERE Email = ?");
        $stmt->bind_param("s", $txtemail);
        $stmt->execute();
        $stmt->store_result();

        if($stmt->num_rows == 0){
            $msg = "<div class='message error'>No account found with that email.</div>";
            $stmt->close();
        } else {
            $stmt->close();

            // Generate 6 digit code
            $code = rand(100000, 999999);
            $expires = date('Y-m-d H:i:s', strtotime('+15 minutes'));

            // Delete any old codes for this email
            $del = $conn->prepare("DELETE FROM PasswordReset WHERE Email = ?");
            $del->bind_param("s", $txtemail);
            $del->execute();
            $del->close();

            // Insert new code
            $ins = $conn->prepare("INSERT INTO PasswordReset (Email, ResetCode, ExpiresAt) VALUES (?, ?, ?)");
            $ins->bind_param("sss", $txtemail, $code, $expires);
            $ins->execute();
            $ins->close();

            // Send email with code
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com';
                $mail->SMTPAuth   = true;
                $mail->Username   = 'totallytoothyclinic@gmail.com';
                $mail->Password   = 'uras fmiw nrne ikph';
                $mail->SMTPSecure = 'tls';
                $mail->Port       = 587;
                $mail->CharSet    = 'UTF-8';

                $mail->setFrom('totallytoothyclinic@gmail.com', 'Totally Toothy Clinic');
                $mail->addAddress($txtemail);

                $mail->Subject = 'Password Reset Code - Totally Toothy Clinic';
                $mail->Body    = "Your password reset code is: $code\n\nThis code expires in 15 minutes.\n\nIf you did not request this, please ignore this email.\n\nRegards,\nTotally Toothy Clinic";

                $mail->send();
                $_SESSION['reset_email'] = $txtemail;
                header("Location: verify_code.php");
                exit();
            } catch (Exception $e) {
                $msg = "<div class='message error'>Failed to send email. Please try again.</div>";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Totally Toothy – Forgot Password</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include("header.php"); ?>
<div class="container">
    <div class="form-box">
        <h2>Forgot Password</h2>
        <?php echo $msg; ?>
        <form method="post" action="forgot_password.php">
            <div class="form-group">
                <label>Enter your registered email:</label>
                <input type="email" name="txtemail" required>
            </div>
            <input type="submit" name="txtsubmit" value="Send Reset Code" class="btn" style="width:100%;">
        </form>
        <p class="small-text"><a href="login.php">Back to Login</a></p>
    </div>
</div>
<?php include("footer.php"); ?>
</body>
</html>