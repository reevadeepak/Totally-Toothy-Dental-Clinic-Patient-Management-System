<?php
session_start();
include("db.php");

if(isset($_GET['treatment_id'])){
    $tid = $_GET['treatment_id'];
    $doc_result = $conn->query("SELECT DISTINCT d.DoctorID, d.FullName 
                                FROM Doctor d
                                JOIN DoctorTreatment dt ON d.DoctorID = dt.DoctorID
                                WHERE dt.TreatmentID = '$tid'
                                ORDER BY d.FullName");
    $doctors = [];
    while($row = $doc_result->fetch_assoc()){
        $doctors[] = $row;
    }
    echo json_encode($doctors);
}
$conn->close();
?>