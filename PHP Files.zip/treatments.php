<?php
session_start();

include("db.php");

$search = "";
$sql = "SELECT * FROM Treatment ORDER BY TreatmentName";

if (isset($_POST['txtsearch'])) {
    $search = $_POST['txtsearch'];
    $sql = "SELECT * FROM Treatment WHERE TreatmentName LIKE '%$search%' ORDER BY TreatmentName";
}

$result = $conn->query($sql);
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Totally Toothy – Treatments</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include("header.php"); ?>

<div class="container section">
    <h2 class="section-title" style="color: #0b6e8a;">Our Dental Treatments</h2>
    <p style="text-align: center; margin-bottom: 20px; color: #555;">
        Explore our range of dental treatments. Click "Book Now" to schedule an appointment.
    </p>

    <!-- Search Form -->
    <div style="text-align: center; margin-bottom: 25px;">
        <form method="post" action="treatments.php">
            <input type="text" name="txtsearch" placeholder="Search treatments..." value="<?php echo $search; ?>" 
                   style="padding: 8px; width: 250px; border-radius: 5px; border: 1px solid #ccc;">
            <input type="submit" value="Search" style="padding: 8px 15px; background: #0b6e8a; color: white; border: none; border-radius: 5px;">
        </form>
        <?php if(!empty($search)): ?>
            <p style="margin-top: 10px;">Showing results for: <strong><?php echo $search; ?></strong></p>
        <?php endif; ?>
    </div>

    <?php if($result && $result->num_rows > 0): ?>
        <div class="treatments-grid">
            <?php while($row = $result->fetch_assoc()): ?>
                <div class="treatment-card-bg" style="background: linear-gradient(rgba(0,0,0,0.65), rgba(0,0,0,0.65)), url('images/<?php echo $row['ImageURL']; ?>'); background-size: cover; background-position: center;">
                    <div class="treatment-card-content">
                        <h3><?php echo $row['TreatmentName']; ?></h3>
                        <p class="treatment-desc"><?php echo $row['Description']; ?></p>
                        <div class="treatment-details">
                            <span class="treatment-price">AED <?php echo $row['Price']; ?></span>
                            <span class="treatment-sessions"><?php echo $row['NumberOfSessions']; ?> session(s)</span>
                        </div>
                        <a href="book_appointment.php?treatment_id=<?php echo $row['TreatmentID']; ?>" class="treatment-book-btn">Book Now</a>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?>
        <p style="text-align: center; color: red;">No treatments found for "<?php echo $search; ?>"</p>
    <?php endif; ?>
</div>

<?php include("footer.php"); ?>