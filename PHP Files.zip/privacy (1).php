<?php include("header.php"); ?>

<div class="container section">
    <h1 class="section-title">Privacy Policy</h1>
    <p style="text-align: center; margin-bottom: 30px; color: #666;">Last Updated: April 2026</p>

    <div class="main-panel" style="margin-bottom: 25px;">
        <p><strong>Totally Toothy Dental Clinic</strong> (“we,” “our,” or “us”) is committed to protecting your privacy. This Privacy Policy explains how we collect, use, and safeguard your personal information when you visit our website or use our services. By using our services, you consent to the data practices described in this policy.</p>
    </div>

    <!-- 1. Information We Collect -->
    <div class="main-panel" style="margin-bottom: 25px;">
        <h3>1. Information We Collect</h3>
        <p>When you interact with Totally Toothy Dental Clinic, we may collect:</p>
        <ul>
            <li><strong>Personal Identifiers:</strong> Name, date of birth, address, email, phone number</li>
            <li><strong>Health Information:</strong> Dental and medical conditions, treatment history, medications</li>
            <li><strong>Payment Information:</strong> Billing details, insurance information</li>
            <li><strong>Website Data:</strong> IP address, browser type, pages visited</li>
        </ul>
    </div>

    <!-- 2. How We Use Your Information -->
    <div class="main-panel" style="margin-bottom: 25px;">
        <h3>2. How We Use Your Information</h3>
        <ul>
            <li>Schedule and manage appointments</li>
            <li>Provide quality dental care and treatment</li>
            <li>Send appointment reminders via email or SMS</li>
            <li>Process payments and insurance claims</li>
            <li>Improve our website and services</li>
            <li>Comply with legal and regulatory requirements (DHA/NABIDH)</li>
        </ul>
    </div>

    <!-- 3. How We Store and Protect Your Information -->
    <div class="main-panel" style="margin-bottom: 25px;">
        <h3>3. How We Store and Protect Your Information</h3>
        <p>In compliance with <strong>Federal Law No. 45 of 2021</strong> and DHA guidelines:</p>
        <ul>
            <li>Electronic records are securely stored with encryption</li>
            <li>Physical records are kept in restricted-access areas</li>
            <li>Only authorized personnel have access to patient information</li>
            <li>Records are securely destroyed when no longer required</li>
            <li>Our team is trained on patient confidentiality</li>
        </ul>
    </div>

    <!-- 4. Information Sharing -->
    <div class="main-panel" style="margin-bottom: 25px;">
        <h3>4. Information Sharing</h3>
        <p>We do <strong>not</strong> sell, trade, or rent your personal information. We may share data only:</p>
        <ul>
            <li>With your consent for treatment or referrals</li>
            <li>With insurance companies for claim processing</li>
            <li>With NABIDH as required by Dubai Health Authority</li>
            <li>When required by law or court order</li>
        </ul>
    </div>

    <!-- 5. Your Rights -->
    <div class="main-panel" style="margin-bottom: 25px;">
        <h3>5. Your Rights</h3>
        <p>You have the right to:</p>
        <ul>
            <li><strong>Access</strong> your personal information</li>
            <li><strong>Correct</strong> inaccurate or incomplete information</li>
            <li><strong>Request deletion</strong> of your data (subject to legal requirements)</li>
            <li><strong>Opt-out</strong> of marketing communications</li>
        </ul>
        <p>To exercise these rights, contact us at <strong>privacy@totallytoothy.com</strong>.</p>
    </div>

    <!-- 6. Cookies -->
    <div class="main-panel" style="margin-bottom: 25px;">
        <h3>6. Cookies</h3>
        <p>Our website uses cookies to improve your browsing experience. Cookies help us remember your login status and preferences. You may disable cookies through your browser settings.</p>
    </div>

    <!-- 7. Children's Privacy -->
    <div class="main-panel" style="margin-bottom: 25px;">
        <h3>7. Children's Privacy</h3>
        <p>We provide pediatric dental services. Information collected from minors requires parental or legal guardian consent. Children's information is not shared except as necessary for their dental care or as required by law.</p>
    </div>

    <!-- 8. Changes to This Policy -->
    <div class="main-panel" style="margin-bottom: 25px;">
        <h3>8. Changes to This Privacy Policy</h3>
        <p>This Privacy Policy may be updated periodically. Changes will be posted on this page with an updated "Last Updated" date.</p>
    </div>

    <!-- 9. Contact Us -->
    <div class="main-panel" style="margin-bottom: 25px;">
        <h3>9. Contact Us</h3>
        <p>For privacy-related questions or concerns:</p>
        <ul>
            <li>Email: <strong>totallytoothyclinic@gmail.com</strong></li>
            <li>Phone: <strong>+971 50467 0790</strong></li>
            <li>Address: Dubai Healthcare City, Dubai, UAE</li>
        </ul>
    </div>

    <p style="text-align: center; color: #888; margin-top: 20px; padding: 20px; background: #f4f8fb; border-radius: 8px;">
         By using our services, you acknowledge that you have read and understood this Privacy Policy. 
    </p>
</div>

<?php include("footer.php"); ?>