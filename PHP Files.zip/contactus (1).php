<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Totally Toothy – Contact Us</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include("header.php"); ?>

<div class="container section">
    <h2 class="section-title">Contact Totally Toothy Dental Clinic</h2>
    <p style="text-align: center; margin-bottom: 30px;">
        Have questions? Need to schedule an appointment? Get in touch with us!
    </p>

    <!-- Contact Information Table -->
    <div class="main-panel" style="margin-bottom: 30px;">
        <h3>Our Contact Information</h3>
        <table style="width: 100%;">
            <tr style="background-color: #0b6e8a; color: white;">
                <th style="padding: 12px;">Contact Method</th>
                <th style="padding: 12px;">Details</th>
            </tr>
            <tr>
                <td style="padding: 10px;"><strong>Phone</strong></td>
                <td style="padding: 10px;">+971 55 41796517 (Main)<br>+971 50 123 4568 (Emergency)</td>
            </tr>
            <tr style="background-color: #f4f8fb;">
                <td style="padding: 10px;"><strong>Email</strong></td>
                <td style="padding: 10px;">totallytoothyclinic@gmail.com</td>
            </tr>
            <tr>
                <td style="padding: 10px;"><strong>Address</strong></td>
                <td style="padding: 10px;">Dubai Healthcare City, Dubai, UAE</td>
            </tr>
            <tr style="background-color: #f4f8fb;">
                <td style="padding: 10px;"><strong>Hours</strong></td>
                <td style="padding: 10px;">Monday - Saturday: 8:00 AM - 5:00 PM<br>Sunday: Closed</td>
            </tr>
            <tr>
                <td style="padding: 10px;"><strong>Instagram</strong></td>
                <td style="padding: 10px;"><a href="https://www.instagram.com/totallytoothydentist" target="_blank" style="text-decoration: underline;">@totallytoothydentist</a></td>
            </tr>
        </table>
    </div>

    <!-- Location Info -->
    <div class="main-panel" style="margin-top: 30px;">
        <h3>Find Us</h3>
        <p>We are located in Dubai Healthcare City, easily accessible by taxi and public transport.</p>
        <p><strong>Parking:</strong> Free parking available for patients.</p>
    </div>
</div>

<?php include("footer.php"); ?>