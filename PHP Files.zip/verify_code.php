<?php
session_start();
include("db.php");

if(!isset($_SESSION['reset_email'])){
    header("Location: forgot_password.php");
    exit();
}

$msg = "";
$email = $_SESSION['reset_email'];

if(isset($_POST['txtsubmit'])){
    $txtcode = $_POST['txtcode'];

    if(empty($txtcode)){
        $msg = "<div class='message error'>Please enter the code.</div>";
    } else {
        $stmt = $conn->prepare("SELECT ResetCode, ExpiresAt FROM PasswordReset WHERE Email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->bind_result($storedCode, $expiresAt);
        $stmt->fetch();
        $stmt->close();

        if(empty($storedCode)){
            $msg = "<div class='message error'>No reset code found. Please try again.</div>";
        } elseif(date('Y-m-d H:i:s') > $expiresAt){
            $msg = "<div class='message error'>Code has expired. <a href='forgot_password.php'>Request a new one.</a></div>";
        } elseif($txtcode != $storedCode){
            $msg = "<div class='message error'>Incorrect code. Please try again.</div>";
        } else {
            $_SESSION['reset_verified'] = true;
            header("Location: reset_password.php");
            exit();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Totally Toothy – Verify Code</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include("header.php"); ?>
<div class="container">
    <div class="form-box">
        <h2>Enter Verification Code</h2>
        <p style="color:#666; margin-bottom:15px;">A 6-digit code has been sent to <strong><?php echo $email; ?></strong>. It expires in 15 minutes.</p>
        <?php echo $msg; ?>
        <form method="post" action="verify_code.php">
            <div class="form-group">
                <label>Verification Code:</label>
                <input type="text" name="txtcode" maxlength="6" required>
            </div>
            <input type="submit" name="txtsubmit" value="Verify Code" class="btn" style="width:100%;">
        </form>
        <p class="small-text"><a href="forgot_password.php">Resend Code</a></p>
    </div>
</div>
<?php include("footer.php"); ?>
</body>
</html>