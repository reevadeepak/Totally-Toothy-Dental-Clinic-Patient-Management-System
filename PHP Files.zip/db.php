<?php
$host = "localhost";
$user = "root";
$pass = "0000";
$dbname = "TotallyToothyClinic";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}
?>