<?php include("header.php"); ?>

<section class="hero">
    <div class="container">
        <?php if (isset($_SESSION['patient_id'])): ?>
            <h1>Welcome to Totally Toothy Dental Clinic,</h1>
            <h1 class="patient-name-hero"><?php echo $_SESSION['patient_name']; ?>!</h1>
            <p class="slogan">"Teeth so clean, they shine on camera"</p>
            <p>Making Dubai smile since 2020. Book your appointment online today.</p>
            <a href="dashboard.php" class="btn">Go to Dashboard</a>
        <?php else: ?>
            <h1>Welcome to Totally Toothy Dental Clinic</h1>
            <p class="slogan">"Teeth so clean, they shine on camera"</p>
            <p>Making Dubai smile since 2020. Book your appointment online today.</p>
            <a href="register.php" class="btn">Get Started</a>
        <?php endif; ?>
    </div>
</section>
<!-- Why Patients Use Our Website Section -->
<section class="section">
    <div class="container">
        <h2 class="section-title">Why Patients Use Our Website</h2>
        <div class="card-grid">
            <div class="card">
                <h3>Easy Appointment Booking</h3>
                <p>Book your dental appointment online without calling the clinic.</p>
            </div>
            <div class="card">
                <h3>View Treatment Prices</h3>
                <p>See treatment options, descriptions, and prices before booking.</p>
            </div>
            <div class="card">
                <h3>Manage Your Visits</h3>
                <p>Check your upcoming and previous appointments in one place.</p>
            </div>
        </div>
    </div>
</section>

<!-- About Us Section -->
<section class="section about-section">
    <div class="container">
        <h2 class="section-title">About Us</h2>
        
        <div class="about-wrapper">
            <div class="about-text">
                <p>Are you looking for a convenient dental office near you? Our experienced dentists work out of our easily accessible location in Dubai Healthcare City. With that location, you'll benefit from top-rated dentistry whether you live in Jumeirah, Marina, Al Furjan, Downtown Dubai, and other nearby areas. In many cases, we're between 2 – 5 miles from the locations just listed, making excellence in dentistry convenient for so many.</p>

                <p>We are a complete family dental center specializing in a wide variety of treatments, including routine services such as teeth cleaning and fillings to advanced procedures including orthodontics, extractions, whitening, and cosmetic enhancements like tooth gem installations. Our team of experienced dentists are dedicated to providing excellent and compassionate care to all their patients. Give our team a call today to learn more or book an appointment online now with our convenient scheduling form.</p>
            </div>
            <div class="about-image">
                <img src="images/dentalpic.jpg" alt="Totally Toothy Dental Clinic">
            </div>
        </div>

        <div class="about-highlights">
            <div class="highlight-box">
                <h3>Convenient Location</h3>
                <p>Dubai Healthcare City<br>Easy access from Jumeirah, Marina, Al Furjan & more</p>
            </div>
            <div class="highlight-box">
                <h3>Experienced Team</h3>
                <p>10+ specialists<br>Decades of combined experience</p>
            </div>
            <div class="highlight-box">
                <h3>Full Service</h3>
                <p>From routine cleaning to<br>full mouth reconstruction</p>
            </div>
            <div class="highlight-box">
                <h3>Affordable Care</h3>
                <p>Insurance accepted<br>Flexible payment plans</p>
            </div>
        </div>
    </div>
</section>

<!-- Our Doctors Section -->
<section class="section doctors-section">
    <div class="container">
        <h2 class="section-title">Our Team Of Skilled Dentists</h2>
        <p class="section-subtitle">Meet our team of experienced dental professionals dedicated to your smile</p>
        
        <div class="doctors-grid">
            <div class="doctor-card">
                <div class="doctor-image-wrapper">
                    <img src="images/mutsawashe_mandinde.jpg" alt="Dr. Mutsawashe Mandinde">
                </div>
                <h3>Dr. Mutsawashe Mandinde</h3>
                <p class="doctor-role">Orthodontist</p>
                <p class="doctor-specialization">Braces & Alignment</p>
            </div>
            <div class="doctor-card">
                <div class="doctor-image-wrapper">
                    <img src="images/reeva_deepak.jpg" alt="Dr. Reeva Deepak">
                </div>
                <h3>Dr. Reeva Deepak</h3>
                <p class="doctor-role">General Dentist</p>
                <p class="doctor-specialization">Cosmetic Dentistry</p>
            </div>
            <div class="doctor-card">
                <div class="doctor-image-wrapper">
                    <img src="images/solomon_orange.jpg" alt="Dr. Solomon Orange">
                </div>
                <h3>Dr. Solomon Orange</h3>
                <p class="doctor-role">Oral Surgeon</p>
                <p class="doctor-specialization">Oral Surgery</p>
            </div>
            <div class="doctor-card">
                <div class="doctor-image-wrapper">
                    <img src="images/esther_blue.jpg" alt="Dr. Esther Blue">
                </div>
                <h3>Dr. Esther Blue</h3>
                <p class="doctor-role">Dental Hygienist</p>
                <p class="doctor-specialization">Periodontics</p>
            </div>
            <div class="doctor-card">
                <div class="doctor-image-wrapper">
                    <img src="images/samuel_sapphire.jpg" alt="Dr. Samuel Sapphire">
                </div>
                <h3>Dr. Samuel Sapphire</h3>
                <p class="doctor-role">Pediatric Dentist</p>
                <p class="doctor-specialization">Children's Dentistry</p>
            </div>
            <div class="doctor-card">
                <div class="doctor-image-wrapper">
                    <img src="images/rachel_rose.jpg" alt="Dr. Rachel Rose">
                </div>
                <h3>Dr. Rachel Rose</h3>
                <p class="doctor-role">Endodontist</p>
                <p class="doctor-specialization">Root Canal Specialist</p>
            </div>
            <div class="doctor-card">
                <div class="doctor-image-wrapper">
                    <img src="images/gideon_gold.jpg" alt="Dr. Gideon Gold">
                </div>
                <h3>Dr. Gideon Gold</h3>
                <p class="doctor-role">Prosthodontist</p>
                <p class="doctor-specialization">Dentures & Implants</p>
            </div>
            <div class="doctor-card">
                <div class="doctor-image-wrapper">
                    <img src="images/hannah_honey.jpg" alt="Dr. Hannah Honey">
                </div>
                <h3>Dr. Hannah Honey</h3>
                <p class="doctor-role">Periodontist</p>
                <p class="doctor-specialization">Gum Disease Specialist</p>
            </div>
            <div class="doctor-card">
                <div class="doctor-image-wrapper">
                    <img src="images/isaac_indigo.jpg" alt="Dr. Isaac Indigo">
                </div>
                <h3>Dr. Isaac Indigo</h3>
                <p class="doctor-role">Oral Surgeon</p>
                <p class="doctor-specialization">Maxillofacial Surgery</p>
            </div>
            <div class="doctor-card">
                <div class="doctor-image-wrapper">
                    <img src="images/phoebe_pear.jpg" alt="Dr. Phoebe Pear">
                </div>
                <h3>Dr. Phoebe Pear</h3>
                <p class="doctor-role">General Dentist</p>
                <p class="doctor-specialization">General Dentistry</p>
            </div>
        </div>
    </div>
</section>


<?php include("footer.php"); ?>