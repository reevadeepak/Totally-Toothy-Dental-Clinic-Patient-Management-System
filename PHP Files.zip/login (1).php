<?php
session_start();

if(isset($_SESSION['patient_id'])){
    header("Location: dashboard.php");
    exit();
}

$servername = "localhost";
$username   = "root";
$password   = "0000";
$db         = "TotallyToothyClinic";
$msg = "";

if(isset($_POST['txtsubmit'])){
    $txtusername = $_POST['txtusername'];
    $txtpassword = $_POST['txtpassword'];

    if(empty($txtusername) || empty($txtpassword)){
        $msg = "<div class='message error'>Both fields are required.</div>";
    } else {
        $conn = new mysqli($servername, $username, $password, $db);
        if($conn->connect_error){
            die("Connection failed: " . $conn->connect_error);
        }

        $stmt = $conn->prepare("SELECT p.PatientID, p.FullName, pu.PasswordHash 
                                FROM PatientUser pu 
                                JOIN Patient p ON pu.PatientID = p.PatientID 
                                WHERE pu.Username = ?");
        $stmt->bind_param("s", $txtusername);
        $stmt->execute();
        $stmt->bind_result($patientID, $fullName, $passwordHash);
        $stmt->fetch();

        if($patientID && password_verify($txtpassword, $passwordHash)){
            $_SESSION["patient_id"]   = $patientID;
            $_SESSION["patient_name"] = $fullName;
            $stmt->close();
            $conn->close();
            header("Location: dashboard.php");
            exit();
        } else {
            $msg = "<div class='message error'>Invalid username or password.</div>";
        }

        $stmt->close();
        $conn->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Totally Toothy – Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php include("header.php"); ?>
<div class="container">
    <div class="form-box">
        <h2>Patient Login</h2>
        <?php echo $msg; ?>
        <form method="post" action="login.php">
            <div class="form-group">
                <label>Username:</label>
                <input type="text" name="txtusername" required>
            </div>
            <div class="form-group">
                <label>Password:</label>
                <input type="password" name="txtpassword" required>
            </div>
            <input type="submit" name="txtsubmit" value="Login" class="btn" style="width:100%;">
            <input type="reset" value="Clear" class="btn" style="width:100%; margin-top:10px; background-color:#ccc;">
        </form>
        <p class="small-text"><a href="forgot_password.php">Forgot Password?</a></p>
        <p class="small-text">No account yet? <a href="register.php">Register here</a></p>
    </div>
</div>
<?php include("footer.php"); ?>
</body>
</html>