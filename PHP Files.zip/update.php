<?php
session_start();

if(!isset($_SESSION['patient_id'])){
    header("Location: login.php");
    exit();
}

include("db.php");

$patientID = $_SESSION['patient_id'];
$msg = "";

// Get current patient data
$result = $conn->query("SELECT * FROM Patient WHERE PatientID = $patientID");
$patient = $result->fetch_assoc();

if(isset($_POST['txtsubmit'])){
    $fullname = $_POST['txtfullname'];
    $contact = $_POST['txtcontact'];
    $email = $_POST['txtemail'];
    $address = $_POST['txtaddress'];

    if(empty($fullname) || empty($email)){
        $msg = "<div class='message error'>Full Name and Email are required.</div>";
    } else {
        $sql = "UPDATE Patient SET 
                FullName = '$fullname', 
                ContactNumber = '$contact', 
                Email = '$email', 
                HomeAddress = '$address' 
                WHERE PatientID = $patientID";
        
        if($conn->query($sql) === TRUE){
            $msg = "<div class='message success'>Profile updated successfully!</div>";
            // Refresh patient data
            $result = $conn->query("SELECT * FROM Patient WHERE PatientID = $patientID");
            $patient = $result->fetch_assoc();
        } else {
            $msg = "<div class='message error'>Update failed. Please try again.</div>";
        }
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Profile</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include("header.php"); ?>

<div class="container">
    <div class="form-box">
        <h2>Update Profile</h2>
        
        <?php echo $msg; ?>
        
        <form method="post" action="update.php">
            <div class="form-group">
                <label>Full Name:</label>
                <input type="text" name="txtfullname" value="<?php echo $patient['FullName']; ?>" required>
            </div>
            
            <div class="form-group">
                <label>Contact Number:</label>
                <input type="text" name="txtcontact" value="<?php echo $patient['ContactNumber']; ?>">
            </div>
            
            <div class="form-group">
                <label>Email:</label>
                <input type="email" name="txtemail" value="<?php echo $patient['Email']; ?>" required>
            </div>
            
            <div class="form-group">
                <label>Home Address:</label>
                <textarea name="txtaddress" rows="3"><?php echo $patient['HomeAddress']; ?></textarea>
            </div>
            
            <input type="submit" name="txtsubmit" value="Update Profile" class="btn" style="width:100%;">
        </form>
    </div>
</div>

<?php include("footer.php"); ?>