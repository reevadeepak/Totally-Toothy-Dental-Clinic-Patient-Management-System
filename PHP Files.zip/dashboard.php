<?php
session_start();

if(!isset($_SESSION['patient_id'])){
    header("Location: login.php");
    exit();
}

include("db.php");

$pid = $_SESSION['patient_id'];
$patientName = $_SESSION['patient_name'];

$today = date('Y-m-d');

$sql_upcoming = "SELECT COUNT(*) AS total FROM Appointment WHERE PatientID = '$pid' AND ApptDate >= '$today'";
$res_upcoming = $conn->query($sql_upcoming);
$row_upcoming = $res_upcoming->fetch_assoc();
$count_upcoming = $row_upcoming['total'];

$sql_past = "SELECT COUNT(*) AS total FROM Appointment WHERE PatientID = '$pid' AND ApptDate < '$today'";
$res_past = $conn->query($sql_past);
$row_past = $res_past->fetch_assoc();
$count_past = $row_past['total'];

$sql_plans = "SELECT COUNT(*) AS total FROM TreatmentPlan WHERE PatientID = '$pid'";
$res_plans = $conn->query($sql_plans);
$row_plans = $res_plans->fetch_assoc();
$count_plans = $row_plans['total'];

$sql_recent = "SELECT a.appointmentid, a.ApptDate, a.ApptTime,
                      t.TreatmentName, d.FullName AS DoctorName
               FROM Appointment a
               JOIN Treatment t ON a.TreatmentID = t.TreatmentID
               JOIN Doctor d ON a.DoctorID = d.DoctorID
               WHERE a.PatientID = '$pid'
               ORDER BY a.ApptDate DESC, a.ApptTime DESC
               LIMIT 1";
$result_recent = $conn->query($sql_recent);

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Totally Toothy – Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include("header.php"); ?>

<div class="container">
    <div class="dashboard">
        <div class="sidebar">
            <h3>Patient Menu</h3>
            <a href="dashboard.php">Dashboard</a>
            <a href="book_appointment.php">Book Appointment</a>
            <a href="my_appointments.php">My Appointments</a>
            <a href="update.php">Update Profile</a>
            <a href="treatments.php">Treatments</a>
            <a href="logout.php">Logout</a>
        </div>

        <div class="main-panel">
            <h2>Welcome, <?php echo $patientName; ?>!</h2>
            <p>Here is a summary of your dental care activity.</p>

            <div class="stats">
                <div class="stat-box">
                    <h4><?php echo $count_upcoming; ?></h4>
                    <p>Upcoming Appointments</p>
                </div>
                <div class="stat-box">
                    <h4><?php echo $count_past; ?></h4>
                    <p>Past Appointments</p>
                </div>
                <div class="stat-box">
                    <h4><?php echo $count_plans; ?></h4>
                    <p>Treatment Plans</p>
                </div>
            </div>

            <h3>Your Most Recent Appointment</h3>

            <?php if($result_recent && $result_recent->num_rows > 0): ?>
                <div style="overflow-x: auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Treatment</th>
                                <th>Doctor</th>
                               
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = $result_recent->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $row['appointmentid']; ?></td>
                                    <td><?php echo $row['ApptDate']; ?></td>
                                    <td><?php echo $row['ApptTime']; ?></td>
                                    <td><?php echo $row['TreatmentName']; ?></td>
                                    <td><?php echo $row['DoctorName']; ?></td>
                                    
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p>You have no appointments yet. <a href="book_appointment.php">Book your first appointment!</a></p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include("footer.php"); ?>