<?php
session_start();

if(!isset($_SESSION['patient_id'])){
    header("Location: login.php");
    exit();
}

include("db.php");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

$msg = "";

$pid = $_SESSION['patient_id'];
$patientName = $_SESSION['patient_name'];

// Fetch treatments for dropdown
$treatments_result = $conn->query("SELECT TreatmentID, TreatmentName, Price FROM Treatment ORDER BY TreatmentName");

// Fetch doctors based on selected treatment (via AJAX)
if(isset($_GET['treatment_id'])){
    $tid = $_GET['treatment_id'];
    $doc_result = $conn->query("SELECT DISTINCT d.DoctorID, d.FullName 
                                FROM Doctor d
                                JOIN DoctorTreatment dt ON d.DoctorID = dt.DoctorID
                                WHERE dt.TreatmentID = '$tid'
                                ORDER BY d.FullName");
    $doctors = [];
    while($row = $doc_result->fetch_assoc()){
        $doctors[] = $row;
    }
    echo json_encode($doctors);
    exit();
}

// Process booking form
if(isset($_POST['txtsubmit'])){

    $txtdate      = $_POST['txtdate'];
    $txttime      = $_POST['txttime'];
    $txtdoctor    = $_POST['txtdoctor'];
    $txttreatment = $_POST['txttreatment'];
    $txtpayment   = $_POST['txtpayment'];

    if(empty($txtdate) || empty($txttime) || empty($txtdoctor) ||
       empty($txttreatment) || empty($txtpayment)){
        $msg = "<div class='message error'>All fields are required.</div>";
    } elseif($txtdate < date('Y-m-d')){
        $msg = "<div class='message error'>Please select a future date.</div>";
    } elseif($txttime < '09:00' || $txttime > '16:30'){
        $msg = "<div class='message error'>Appointments can only be booked between 9:00 AM and 4:30 PM.</div>";
    } else {
        $checkDoctor = $conn->query("SELECT AppointmentID FROM Appointment WHERE DoctorID = '$txtdoctor' AND ApptDate = '$txtdate' AND ApptTime = '$txttime'");
        
        if($checkDoctor->num_rows > 0){
            $msg = "<div class='message error'>Selected doctor is not available at that time.</div>";
        } else {
            $idResult = $conn->query("SELECT IFNULL(MAX(AppointmentID), 0) + 1 AS NextID FROM Appointment");
            $idRow = $idResult->fetch_assoc();
            $newAppointmentID = $idRow["NextID"];
            
            $sql_appt = "INSERT INTO Appointment (AppointmentID, ApptDate, ApptTime, BookingMethod, PaymentType, PatientID, DoctorID, TreatmentID, TreatmentPlanID) 
                         VALUES ('$newAppointmentID', '$txtdate', '$txttime', 'Online', '$txtpayment', '$pid', '$txtdoctor', '$txttreatment', NULL)";
            
            if($conn->query($sql_appt) === TRUE){
                $priceResult = $conn->query("SELECT Price FROM Treatment WHERE TreatmentID = '$txttreatment'");
                $priceRow = $priceResult->fetch_assoc();
                $price = $priceRow['Price'];

                $treatResult = $conn->query("SELECT TreatmentName FROM Treatment WHERE TreatmentID = '$txttreatment'");
                $treatRow = $treatResult->fetch_assoc();
                $treatmentName = $treatRow['TreatmentName'];

                $docResult = $conn->query("SELECT FullName FROM Doctor WHERE DoctorID = '$txtdoctor'");
                $docRow = $docResult->fetch_assoc();
                $doctorName = $docRow['FullName'];

                $emailResult = $conn->query("SELECT Email FROM Patient WHERE PatientID = '$pid'");
                $emailRow = $emailResult->fetch_assoc();
                $patientEmail = $emailRow['Email'];
                
                $invResult = $conn->query("SELECT IFNULL(MAX(InvoiceID), 0) + 1 AS NextID FROM Invoice");
                $invRow = $invResult->fetch_assoc();
                $newInvoiceID = $invRow["NextID"];
                
                $sql_invoice = "INSERT INTO Invoice (InvoiceID, Amount, IssueDate, PaymentStatus, PaymentMethod, AppointmentID) 
                                VALUES ('$newInvoiceID', '$price', CURDATE(), 'Pending', '$txtpayment', '$newAppointmentID')";
                $conn->query($sql_invoice);

                $mail = new PHPMailer(true);
                try {
                    $mail->isSMTP();
                    $mail->Host       = 'smtp.gmail.com';
                    $mail->SMTPAuth   = true;
                    $mail->Username   = 'totallytoothyclinic@gmail.com';
                    $mail->Password   = 'uras fmiw nrne ikph';
                    $mail->SMTPSecure = 'tls';
                    $mail->Port       = 587;
                    $mail->CharSet    = 'UTF-8';

                    $mail->setFrom('totallytoothyclinic@gmail.com', 'Totally Toothy Clinic');
                    $mail->addAddress($patientEmail, $patientName);

                    $mail->Subject = 'Appointment Confirmation - Totally Toothy Clinic';
                    $mail->Body    = "Dear $patientName,\n\nYour appointment has been successfully booked!\n\nAppointment Details:\nDate: $txtdate\nTime: $txttime\nDoctor: $doctorName\nTreatment: $treatmentName\nPayment Method: $txtpayment\nInvoice Amount: AED $price\n\nPlease arrive 10 minutes early.\n\nRegards,\nTotally Toothy Clinic";

                    $mail->send();
                } catch (Exception $e) {
                    // Email failed but booking still went through
                }
                
                $msg = "<div class='message success'>Appointment booked successfully! Invoice of AED $price has been generated. <a href='my_appointments.php'>View My Appointments</a></div>";
            } else {
                $msg = "<div class='message error'>Booking failed. Please try again.</div>";
            }
        }
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Totally Toothy – Book Appointment</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include("header.php"); ?>

<div class="container">
    <div class="form-box">
        <h2>Book a Dental Appointment</h2>

        <?php echo $msg; ?>

        <form method="post" action="book_appointment.php">
            <div class="form-group">
                <label>Appointment Date:</label>
                <input type="date" name="txtdate" min="<?php echo date('Y-m-d'); ?>" required>
            </div>

            <div class="form-group">
                <label>Appointment Time <small style="color:#666;">(9:00 AM – 4:30 PM)</small>:</label>
                <input type="time" name="txttime" min="09:00" max="16:30" required>
            </div>

            <div class="form-group">
                <label>Select Treatment:</label>
                <select name="txttreatment" id="txttreatment" required onchange="loadDoctors(this.value)">
                    <option value="">-- Select Treatment --</option>
                    <?php while($row = $treatments_result->fetch_assoc()): ?>
                        <option value="<?php echo $row['TreatmentID']; ?>">
                            <?php echo $row['TreatmentName']; ?> (AED <?php echo $row['Price']; ?>)
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="form-group">
                <label>Choose a Doctor:</label>
                <select name="txtdoctor" id="txtdoctor" required>
                    <option value="">-- Select Treatment First --</option>
                </select>
            </div>

            <div class="form-group">
                <label>Payment Method:</label>
                <div class="radio-group">
                    <input type="radio" name="txtpayment" value="Cash" required> <label>Cash</label>
                    <input type="radio" name="txtpayment" value="Card"> <label>Card</label>
                    <input type="radio" name="txtpayment" value="Mobile Money"> <label>Mobile Money</label>
                </div>
            </div>

            <input type="submit" name="txtsubmit" value="Book Appointment" class="btn" style="width:100%;">
            <input type="reset" value="Clear" class="btn" style="width:100%; margin-top:10px; background-color:#ccc;">
        </form>
    </div>
</div>

<script>
function loadDoctors(treatmentID){
    const doctorSelect = document.getElementById('txtdoctor');
    doctorSelect.innerHTML = '<option value="">-- Loading... --</option>';

    if(treatmentID == ''){
        doctorSelect.innerHTML = '<option value="">-- Select Treatment First --</option>';
        return;
    }

    fetch('book_appointment.php?treatment_id=' + treatmentID)
        .then(response => response.json())
        .then(doctors => {
            doctorSelect.innerHTML = '<option value="">-- Select Doctor --</option>';
            if(doctors.length == 0){
                doctorSelect.innerHTML = '<option value="">No doctors available for this treatment</option>';
            } else {
                doctors.forEach(doc => {
                    doctorSelect.innerHTML += '<option value="' + doc.DoctorID + '">' + doc.FullName + '</option>';
                });
            }
        });
}
</script>

<?php include("footer.php"); ?>