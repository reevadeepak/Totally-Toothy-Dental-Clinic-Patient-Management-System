<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Get current page name
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Totally Toothy Dental Clinic</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
     <div class="container nav">
        <div class="logo">
            <a href="index.php">
               <img src="images/logosss.jpg" alt="Totally Toothy Dental Clinic" class="logo-img">
            </a>
            <div class="logo-text">Totally Toothy Dental Clinic</div>
        </div>
        <nav>
            <ul>
                <li><a href="index.php" <?php echo ($current_page == 'index.php') ? 'class="active"' : ''; ?>>Home</a></li>
                <li><a href="treatments.php" <?php echo ($current_page == 'treatments.php') ? 'class="active"' : ''; ?>>Treatments</a></li>
                
                <?php if (isset($_SESSION['patient_id'])): ?>
                    <li><a href="dashboard.php" <?php echo ($current_page == 'dashboard.php') ? 'class="active"' : ''; ?>>Dashboard</a></li>
                    <li><a href="book_appointment.php" <?php echo ($current_page == 'book_appointment.php') ? 'class="active"' : ''; ?>>Book Appointment</a></li>
                    <li><a href="my_appointments.php" <?php echo ($current_page == 'my_appointments.php') ? 'class="active"' : ''; ?>>My Appointments</a></li>
                    <li><a href="update.php" <?php echo ($current_page == 'update.php') ? 'class="active"' : ''; ?>>Update Profile</a></li>
                    <li><a href="search_slots.php" <?php echo ($current_page == 'search_slots.php') ? 'class="active"' : ''; ?>>Find Available Slots</a></li>
                    <li><a href="contactus.php" <?php echo ($current_page == 'contactus.php') ? 'class="active"' : ''; ?>>Contact Us</a></li>
                    <li><a href="logout.php">Logout</a></li>
                   
                <?php else: ?>
                    <li><a href="register.php" <?php echo ($current_page == 'register.php') ? 'class="active"' : ''; ?>>Register</a></li>
                    <li><a href="login.php" <?php echo ($current_page == 'login.php') ? 'class="active"' : ''; ?>>Login</a></li>
                <?php endif; ?>
                
            </ul>
        </nav>
    </div>
</header>
<div class="advertisement">
    <h3> Special Offer!</h3>
    <p>20% off on first appointment</p>
    <p>Call: +971 50 123 4567</p>
    <a href="book_appointment.php" class="btn">Book Now</a>
</div>