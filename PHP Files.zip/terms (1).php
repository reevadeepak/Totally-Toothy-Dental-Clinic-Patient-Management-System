<?php include("header.php"); ?>

<div class="container section">
    <h1 class="section-title">Terms & Conditions</h1>
    <p style="text-align: center; margin-bottom: 30px; color: #666;">Last Updated: April 2026</p>
    
    <div class="main-panel" style="margin-bottom: 25px;">
        <p><strong>Please read the following terms and conditions carefully before using this site.</strong> All users of Totally Toothy Dental Clinic website are subject to the following terms and conditions and other applicable laws of the United Arab Emirates and Dubai Health Authority (DHA).</p>
    </div>
    
    <!-- 1. Disclaimer and Limitation of Liabilities -->
    <div class="main-panel" style="margin-bottom: 25px;">
        <h3>1. Disclaimer and Limitation of Liabilities</h3>
        <p>All the contents provided by Totally Toothy Dental Clinic are intended for information and education purposes only. Totally Toothy Dental Clinic makes no representations as to the accuracy, timeliness and completeness of any of the information on this site. The owner will not be liable for any errors or omissions in this information nor for the availability of this information.</p>
        <p>Totally Toothy Dental Clinic takes no responsibility for external websites hyperlinked to this site and any such hyperlinking does not indicate any relationships or endorsements from such websites or resources.</p>
        <p><strong>No doctor-patient relationship is established upon your use of this site.</strong> This website does not intend to offer particular dental, medical or surgical advice to anyone. Blogs and articles are not proposed as tools of self-diagnosis or substitutes for proper dental advice.</p>
        <p>Totally Toothy Dental Clinic does not endorse nor reflect the information, opinions, claims or advice shared and posted by our visitors. It does not warrant that the website and all its contents will be uninterrupted, timely, secure, error-free or virus-free.</p>
    </div>
    
    <!-- 2. Patient Rights & Responsibilities -->
    <div class="main-panel" style="margin-bottom: 25px;">
        <h3>2. Patient Rights & Responsibilities</h3>
        <p>In accordance with <strong>Ministerial Resolution No. 14 of 2021</strong> and <strong>Dubai Health Authority (DHA) guidelines</strong>:</p>
        
        <h4>Patient Rights</h4>
        <ul>
            <li>Receive quality dental care regardless of race, nationality, religion, gender, or age</li>
            <li>Have their medical information kept confidential and private</li>
            <li>Be treated with respect, dignity, and consideration</li>
            <li>Receive clear information about their diagnosis, treatment options, and costs</li>
            <li>Refuse treatment and be informed of the consequences of refusal</li>
            <li>Access their medical records upon request</li>
        </ul>
        
        <h4>Patient Duties</h4>
        <ul>
            <li>Provide accurate and complete medical history information</li>
            <li>Follow the treatment plan recommended by their dentist</li>
            <li>Respect clinic staff, other patients, and clinic property</li>
            <li>Adhere to appointment schedules and cancellation policies</li>
            <li>Inform the clinic of any changes to personal or insurance information</li>
        </ul>
    </div>
    
    <!-- 3. Informed Consent -->
    <div class="main-panel" style="margin-bottom: 25px;">
        <h3>3. Informed Consent</h3>
        <p>In compliance with <strong>Dubai Health Authority (DHA) Guidelines for Patient Consent</strong>:</p>
        <ul>
            <li><strong>Written consent</strong> is mandatory prior to any surgical or invasive procedure (including extractions, root canals, implants, and braces)</li>
            <li>All treatment information will be provided in a language the patient understands</li>
            <li>Patients will be informed of potential risks, benefits, and alternatives before any procedure</li>
            <li>Consent forms will be signed and kept in the patient's medical file</li>
            <li>Patients may withdraw consent at any time before the procedure begins</li>
        </ul>
    </div>
    
    <!-- 4. Appointment Booking & Cancellation Policy -->
    <div class="main-panel" style="margin-bottom: 25px;">
        <h3>4. Appointment Booking & Cancellation Policy</h3>
        <ul>
            <li><strong>Cancellation Notice:</strong> Patients must provide at least <strong>24 hours notice</strong> for cancellation or rescheduling</li>
            <li><strong>No-Show Fee:</strong> Failure to attend an appointment without notice will result in a fee of <strong>500 AED</strong> or 100% of the deposit paid</li>
            <li><strong>Late Policy:</strong> Arriving more than <strong>20 minutes late</strong> may result in cancellation of the appointment and a rescheduling fee</li>
            <li>Emergency cancellations due to illness will be accommodated without penalty with valid documentation</li>
            <li>Repeated no-shows may result in requiring full pre-payment for future appointments</li>
        </ul>
    </div>
    
    <!-- 5. Financial & Payment Terms -->
    <div class="main-panel" style="margin-bottom: 25px;">
        <h3>5. Financial & Payment Terms</h3>
        <ul>
            <li><strong>Fee Disclosure:</strong> All treatment costs will be clearly explained during consultation before any procedure begins</li>
            <li><strong>Payment Methods:</strong> We accept Cash, Credit/Debit Cards (Visa/Mastercard), and Mobile Money</li>
            <li><strong>Insurance:</strong> Direct billing is available for approved insurance providers. Patients are responsible for co-payments and any claims denied by their insurance</li>
            <li>Full payment is required at the time of service unless prior arrangements have been made</li>
            <li>Treatment plans involving multiple sessions may require a deposit before the first appointment</li>
        </ul>
    </div>
    
    <!-- 6. Patient Confidentiality & Data Privacy -->
    <div class="main-panel" style="margin-bottom: 25px;">
        <h3>6. Patient Confidentiality & Data Privacy</h3>
        <p>In compliance with <strong>Federal Law No. 45 of 2021</strong> (Protection of Personal Data) and DHA guidelines:</p>
        <ul>
            <li>We store electronic and hard records <strong>securely and confidentially</strong></li>
            <li>Records are securely destroyed when no longer required</li>
            <li>Confidential information is only seen by staff who need to see it</li>
            <li>Our team is trained on policies and procedures to keep patient information confidential</li>
            <li><strong>NABIDH Compliance (Dubai):</strong> Your records may be shared with the NABIDH health information exchange system as required by DHA regulations</li>
            <li>You have the right to request access to or correction of your personal data</li>
        </ul>
    </div>
    
    <!-- 7. User-Generated Content -->
    <div class="main-panel" style="margin-bottom: 25px;">
        <h3>7. User-Generated Content</h3>
        <p>By submitting any content (comments, messages, texts, photographs, graphics, or videos) to Totally Toothy Dental Clinic's website, blog, or social media, you permit Totally Toothy Dental Clinic <strong>non-exclusive, perpetual, and full rights</strong> to remove, edit, publish, and distribute contents of such postings and comments.</p>
        <p>Totally Toothy Dental Clinic reserves the right to remove comments/postings that are deemed inappropriate, including those that are:</p>
        <ul>
            <li>Abusive, hurtful (racial, ethnic, or gender-bashing), defamatory, or obscene</li>
            <li>Off-topic, irrelevant, or redundant</li>
            <li>Fraudulent, deceptive, or misleading</li>
            <li>Illegal or containing violations of copyrights and intellectual property rights of another</li>
        </ul>
    </div>
    
    <!-- 8. Trademarks -->
    <div class="main-panel" style="margin-bottom: 25px;">
        <h3>8. Trademarks</h3>
        <p>All trademarks, service marks, and trade names, including the company name and logo of <strong>Totally Toothy Dental Clinic</strong>, are owned and registered trademarks of Totally Toothy Dental Clinic. Unauthorized use is prohibited.</p>
    </div>
    
    <!-- 9. Copyright -->
    <div class="main-panel" style="margin-bottom: 25px;">
        <h3>9. Copyright</h3>
        <p>The entire content of this website, including but not limited to text, graphics, music, videos, and code, is copyrighted under International Copyright Conventions and other copyright laws, and is the property of <strong>Totally Toothy Dental Clinic</strong>.</p>
        <p>You may download or reprint materials for your own personal and non-commercial use, provided you include all applicable notices and disclaimers. Any other use of the materials is strictly prohibited without our prior written permission.</p>
        <p><strong>ALL RIGHTS RESERVED.</strong></p>
    </div>
    
    <!-- 10. Changes to Terms -->
    <div class="main-panel" style="margin-bottom: 25px;">
        <h3>10. Changes to Terms & Conditions</h3>
        <p>The policies, disclaimers, and limitation of liabilities are subject to change at any time without notice to readers and visitors. It is your responsibility to review these Terms & Conditions periodically for changes.</p>
    </div>
    
    <!-- 11. Contact Information -->
    <div class="main-panel" style="margin-bottom: 25px;">
        <h3>11. Contact Us</h3>
        <p>For questions about these Terms & Conditions:</p>
        <ul>
            <li>Email: <strong>totallytoothyclinic@gmail.com</strong></li>
            <li>Phone: <strong>+971 50467 0790</strong></li>
            <li>Address: Dubai Healthcare City, Dubai, UAE</li>
        </ul>
    </div>
    
    <p style="text-align: center; color: #888; margin-top: 20px; padding: 20px; background: #f4f8fb; border-radius: 8px;">
         By using our services and website, you acknowledge that you have read, understood, and agree to these Terms & Conditions. 
    </p>
</div>

<?php include("footer.php"); ?>