<?php
session_start();

if(!isset($_SESSION['patient_id'])){
    header("Location: login.php");
    exit();
}

include("db.php");

// All possible time slots
$all_slots = [
    '09:00:00', '09:30:00', '10:00:00', '10:30:00',
    '11:00:00', '11:30:00', '12:00:00', '12:30:00',
    '14:00:00', '14:30:00', '15:00:00', '15:30:00',
    '16:00:00', '16:30:00'
];

$booked_slots = [];
$selected_doctor = "";
$selected_date = "";
$show_grid = false;
$doctor_info = null;

// Fetch doctors for dropdown
$doctors_result = $conn->query("SELECT DoctorID, FullName, Specialization FROM Doctor ORDER BY FullName");

// Process search form
if(isset($_POST['txtsubmit'])){
    $selected_doctor = $_POST['txtdoctor'];
    $selected_date = $_POST['txtdate'];

    if(!empty($selected_doctor) && !empty($selected_date)){
        // Get doctor information
        $sql_doctor = "SELECT DoctorID, FullName, Specialization FROM Doctor WHERE DoctorID = '$selected_doctor'";
        $res_doctor = $conn->query($sql_doctor);
        if($res_doctor && $res_doctor->num_rows > 0){
            $doctor_info = $res_doctor->fetch_assoc();
        }
        
        // Get booked slots for this doctor on this date
        $sql_booked = "SELECT ApptTime FROM Appointment 
                       WHERE DoctorID = '$selected_doctor' 
                       AND ApptDate = '$selected_date'";
        $res_booked = $conn->query($sql_booked);
        
        while($row = $res_booked->fetch_assoc()){
            $booked_slots[] = $row['ApptTime'];
        }
        $show_grid = true;
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Totally Toothy – Find Available Slots</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include("header.php"); ?>

<div class="container">
    <div class="form-box">
        <h2>Find Available Appointment Slots</h2>
        <p>Select a doctor and date to see available times.</p>

        <form method="post" action="search_slots.php">
            <div class="form-group">
                <label>Select Doctor:</label>
                <select name="txtdoctor" required>
                    <option value="">-- Select Doctor --</option>
                    <?php while($row = $doctors_result->fetch_assoc()): ?>
                        <option value="<?php echo $row['DoctorID']; ?>"
                            <?php echo ($selected_doctor == $row['DoctorID']) ? 'selected' : ''; ?>>
                            <?php echo $row['FullName']; ?> - <?php echo $row['Specialization']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="form-group">
                <label>Select Date:</label>
                <input type="date" name="txtdate" min="<?php echo date('Y-m-d'); ?>" 
                       value="<?php echo $selected_date; ?>" required>
            </div>

            <input type="submit" name="txtsubmit" value="Search Slots" class="btn" style="width:100%;">
        </form>
    </div>

    <?php if($show_grid): ?>
        <div class="main-panel" style="margin-top: 30px;">
            <!-- Doctor Information Card -->
            <?php if($doctor_info): ?>
                <div class="doctor-info-card">
                    <div class="doctor-info-header">
                        <h3> Dr. <?php echo $doctor_info['FullName']; ?></h3>
                        <span class="doctor-specialization-badge"><?php echo $doctor_info['Specialization']; ?></span>
                    </div>
                    <div class="doctor-info-date">
                        <p> Selected Date: <?php echo date('l, F j, Y', strtotime($selected_date)); ?></p>
                    </div>
                </div>
            <?php endif; ?>
            
            <h3>Available Slots on <?php echo $selected_date; ?></h3>
            
            <?php
            $available_count = 0;
            foreach($all_slots as $slot):
                if(!in_array($slot, $booked_slots)):
                    $available_count++;
                endif;
            endforeach;
            ?>
            
            <?php if($available_count > 0): ?>
                <div class="slots-grid">
                    <?php foreach($all_slots as $slot): ?>
                        <?php if(in_array($slot, $booked_slots)): ?>
                            <div class="slot-booked"><?php echo substr($slot, 0, 5); ?><br><small>Booked</small></div>
                        <?php else: ?>
                            <a href="book_appointment.php?doctor_id=<?php echo $selected_doctor; ?>&date=<?php echo $selected_date; ?>&time=<?php echo $slot; ?>" 
                               class="slot-available">
                                <?php echo substr($slot, 0, 5); ?><br><small>Available</small>
                            </a>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p class="message error">No available slots found for this doctor on this date.</p>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<style>
/* Doctor Information Card Styles */
.doctor-info-card {
    background: linear-gradient(135deg, #eef9fc 0%, #dff4f9 100%);
    border-left: 5px solid #0b6e8a;
    border-radius: 10px;
    padding: 20px;
    margin-bottom: 25px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}

.doctor-info-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 15px;
    margin-bottom: 10px;
}

.doctor-info-header h3 {
    color: #0b6e8a;
    font-size: 20px;
    margin: 0;
}

.doctor-specialization-badge {
    background: #0b6e8a;
    color: white;
    padding: 6px 15px;
    border-radius: 25px;
    font-size: 14px;
    font-weight: bold;
}

.doctor-info-date p {
    margin: 5px 0 0 0;
    color: #555;
    font-size: 14px;
}

.doctor-info-date strong {
    color: #0b6e8a;
}

/* Responsive */
@media (max-width: 768px) {
    .doctor-info-header {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .doctor-info-card {
        padding: 15px;
    }
}
</style>

<?php include("footer.php"); ?>